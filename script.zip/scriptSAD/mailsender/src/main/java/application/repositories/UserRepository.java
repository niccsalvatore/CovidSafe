package application.repositories;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import application.entity.Identifier;
import application.entity.User;

@RepositoryRestResource
public interface UserRepository extends JpaRepository<User,Identifier> {
	User findByIdentifier(Identifier identifier);

}
