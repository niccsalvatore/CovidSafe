package application.configuration;

public class ConfigurationConstants {
	public static final String MAIL_SENDER_ADDRESS = "giaocomotre45@gmail.com";
	public static final String MAIL_SUBJECT = "COVID-19 Exposure";
	public static final String MAIL_MESSAGE = "Si informa l'utente di essere entrato in contatto con un paziente affetto da COVID-19.";


}
