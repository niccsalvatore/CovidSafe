package application.services;
import application.configuration.ConfigurationConstants;
import java.util.ArrayList;
import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.mail.MailException;
	import org.springframework.mail.SimpleMailMessage;
	import org.springframework.mail.javamail.JavaMailSender;
	import org.springframework.scheduling.annotation.Async;
	import org.springframework.stereotype.Service;

import application.entity.Identifier;
import application.entity.User;
import application.repositories.UserRepository;

	@Service
	public class MailService  {

		@Autowired
		private JavaMailSender javaMailSender;
		
		@Autowired
		private UserRepository userRepository;

		@Autowired
		public MailService(JavaMailSender javaMailSender,UserRepository userRepository){
			this.userRepository = userRepository;
			this.javaMailSender = javaMailSender;
		}
		public List<String> getMails (List<Identifier> identifierList){
			List<String> mails = new ArrayList<String>( );
			for(Identifier identifier : identifierList) {
			User user  =	userRepository.findByIdentifier(identifier);
			if(user!=null) {
			String email= user.getEmail();
			 mails.add(email);
			}
			}
		return mails;
		}
		
		@Async
		public void sendNotification(List<String> mails) throws MailException, InterruptedException {
			for(String mail:mails) {
		        SimpleMailMessage mailObject = new SimpleMailMessage();
				mailObject.setTo(mail);
				mailObject.setFrom(ConfigurationConstants.MAIL_SENDER_ADDRESS);
				mailObject.setSubject(ConfigurationConstants.MAIL_SUBJECT);
				mailObject.setText(ConfigurationConstants.MAIL_MESSAGE);
				javaMailSender.send(mailObject);
				System.out.println("Email Sent!");
			}
		}
	}