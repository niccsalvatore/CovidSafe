package application;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMessage;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import application.entity.Identifier;
import application.services.MailService;

@RestController
public class MailController {


	private Logger logger = LoggerFactory.getLogger(MailController.class);
	
	@Autowired
	private MailService mailService;
	
	@PostMapping(path="/notificationService", produces="application/json")
	public void sendMailSuccess(@RequestBody List<Identifier> identifiers) throws MailException, InterruptedException{
		List<String> mails=mailService.getMails(identifiers);
		mailService.sendNotification(mails);
	}

}
