package application.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;


@Embeddable
public class Identifier implements Serializable {
    @NotNull
    private int minor;

    @NotNull
    private int major;

    public Identifier() {

    }

    public Identifier(int minor,int major) {
        this.minor=minor;
        this.major=major;
    }
    
    
    
    
    public int getMinor() {
		return minor;
	}

	public void setMinor(int minor) {
		this.minor = minor;
	}

	public int getMajor() {
		return major;
	}

	public void setMajor(int major) {
		this.major = major;
	}

	public String toString() {
		String result = "minor : " + minor +"\nmajor :" + major;
		return result;
	}
}