package com.progetto.covidsafe.UI;

public interface DeclarePositiveInterface {
    void notifyResponse(String string);
}
