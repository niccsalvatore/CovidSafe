package com.progetto.covidsafe.utils;
import androidx.room.TypeConverter;
import java.util.Date;

/*Con questa classe,Room attraverso i metodi toDate e fromDate(annotati opportunamente con @TypeConverter in maniera tale da essere riconosciuti)
* riesce a salvare opportunamente un oggetto di tipo date sul database e viceversa*/

public class DateConverter {

    @TypeConverter
    public static Date toDate(Long dateLong){
        return dateLong == null ? null: new Date(dateLong);
    }

    @TypeConverter
    public static Long fromDate(Date date){
        return date == null ? null : date.getTime();
    }
    }
