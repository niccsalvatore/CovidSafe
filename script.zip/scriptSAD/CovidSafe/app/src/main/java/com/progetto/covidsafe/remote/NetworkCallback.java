package com.progetto.covidsafe.remote;

public interface NetworkCallback {
    void onSuccess(String message);
    void onFailure(String error);
}
