package com.progetto.covidsafe.utils;

import java.util.Date;

public class ConfigurationConstants {
    public static final String BASE_MAIL_URL ="http://X.X.X.X:8090/";
    public static final String POST_REQUEST_RELATIVE_URL="notificationService";
    public static final String WEB_SERVICE_AUTH_USERNAME = "root";
    public static final String WEB_SERVICE_AUTH_PASSWORD ="";
    public static final String APPLICATION_UUID="aaaaaaaa-bbbb-bbbb-aaaa-123456789aaa";
    public static final String TRANSMITTER_MINOR="2";
    public static final String TRANSMITTER_MAJOR="3";
    public static final int PERMISSION_REQUEST_FINE_LOCATION = 1;
    public static final int PERMISSION_REQUEST_BACKGROUND_LOCATION = 2;
    public static Date DECLARATION_DATE=new Date(0);
    //TODO : i minor ed i major dovrebbero essere assegnati univocamente da un servizio appositamente implementato,non sono costanti ma le assegnamo solo come stub,per comodità
}
