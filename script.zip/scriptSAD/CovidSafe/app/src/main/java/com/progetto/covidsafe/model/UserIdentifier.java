package com.progetto.covidsafe.model;
import org.jetbrains.annotations.NotNull;

public class UserIdentifier {


    private int  minor;
    private int major;

    public UserIdentifier(int minor,int major) {
        this.minor=minor;
        this.major=major;
    }

    public int getMinor() {
        return minor;
    }

    public void setMinor(int minor) {
        this.minor = minor;
    }

    public int getMajor() {
        return major;
    }

    public void setMajor(int major) {
        this.major = major;
    }

    @NotNull
    public String toString() {
        return "minor : " + minor +"\nmajor :" + major;
    }
    @Override
    public boolean equals(Object o){
        UserIdentifier userIdentifier = (UserIdentifier) o ;
        return this.getMajor() == userIdentifier.getMajor() && this.getMinor() == userIdentifier.getMinor();
    }

}