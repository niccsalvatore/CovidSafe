package com.progetto.covidsafe.local;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.utils.DateConverter;


@Database(entities = Contact.class,version = 4)
@TypeConverters({DateConverter.class})
public abstract class LocalDatabase extends RoomDatabase {
    public abstract ContactDAO contactDAO();
    private static LocalDatabase instance;

    public static synchronized LocalDatabase getInstance(Context context){
        if (instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),LocalDatabase.class,"ContactDatabse")
                    .fallbackToDestructiveMigration().build();
        }
        return instance;
    }
}