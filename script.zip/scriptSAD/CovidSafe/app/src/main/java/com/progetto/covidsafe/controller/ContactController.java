package com.progetto.covidsafe.controller;

import android.app.Application;
import com.progetto.covidsafe.remote.NetworkCallback;
import com.progetto.covidsafe.local.RepositoryInterface;
import com.progetto.covidsafe.UI.DeclarePositiveInterface;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.model.UserIdentifier;
import com.progetto.covidsafe.local.ContactRepository;
import com.progetto.covidsafe.remote.Network;
import org.altbeacon.beacon.Beacon;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import static com.progetto.covidsafe.utils.ConfigurationConstants.DECLARATION_DATE;

public class ContactController implements ContactControllerInterface {
    private List<Contact> previousScan = new ArrayList<>();
    private Network network;
    private  RepositoryInterface repositoryInterface;
    private DeclarePositiveInterface declarePositiveInterface;
    private static ContactController contactController;



    private ContactController(Application application, DeclarePositiveInterface declarePositiveInterface) {
        this.network = Network.getInstance();
        repositoryInterface= ContactRepository.getInstance(application);
        this.declarePositiveInterface = declarePositiveInterface;
    }
    private ContactController(Application application) {
        this.network = Network.getInstance();
        repositoryInterface= ContactRepository.getInstance(application);
    }


    public static synchronized ContactController getInstance(Application application,DeclarePositiveInterface declarePositiveInterface){

        if (contactController==null && declarePositiveInterface==null){
            contactController = new ContactController(application);
        }
        else if(declarePositiveInterface!=null){
            contactController = new ContactController(application,declarePositiveInterface);
        }


        return contactController;
    }
/*    public static synchronized ContactController getInstance(Application application){

        if(contactController==null){
            contactController = new ContactController(application);
        }

        return contactController;
    }*/
    @Override
    //Algoritmo di riconoscimento dei contatti
    public void checkContacts (Collection<Beacon> beacons) {
        List<Beacon> currentScan = new ArrayList<>(beacons);
        for (int i = 0; i < currentScan.size(); i++) {
            //se la distanza è inferiore a due metri
            if (currentScan.get(i).getDistance() < 2) {
                //costruisci un oggetto di tipo contatto
                UserIdentifier userIdentifier = new UserIdentifier(currentScan.get(i).getId2().toInt(), currentScan.get(i).getId3().toInt());
                Date date = new Date();
                Contact contact = new Contact(userIdentifier, date);
                //Se la scansione attuale e quella precedente contengono un contatto allora sono passati 10 minuti : -> inserire nel database
                //ed eliminare il contatto dalla scansione corrente
                if (previousScan.contains(contact)) {
                    repositoryInterface.insertContact(contact);
                    currentScan.remove(i);
                }
            }
        }
        previousScan.clear();
        //aggiungi i restanti beacon della scansione corrente al vettore relativo alla scansione precedente: alla prossima scansione il controllo
        //verrà ripetuto
        for (Beacon beacon : currentScan) {
            UserIdentifier userIdentifier = new UserIdentifier(beacon.getId2().toInt(), beacon.getId3().toInt());
            Date date = new Date();
            Contact contact = new Contact(userIdentifier, date);
            previousScan.add(contact);
        }
    }

    @Override
    public void notifyPositivity() {
        //se la dichiarazione è avvenuta ad almeno sette giorni di distanza,la successiva dichiarazione è da considerarsi lecita
        if (System.currentTimeMillis() - DECLARATION_DATE.getTime() > 1000 * 60 * 60 * 24 * 7) {
            repositoryInterface.syncGetAllUserIdentifiers(this);
        }
        else{
            declarePositiveInterface.notifyResponse("Hai già dichiarato la tua positività negli ultimi 7 giorni!");
        }
    }

    @Override
    public void returnIdentifiers(List<UserIdentifier> userIdentifiers) {

            if (!userIdentifiers.isEmpty() ) {
                network.sendIdentifiers(userIdentifiers, new NetworkCallback() {
                    @Override
                    public void onSuccess(String message) {
                        System.out.println(message);
                        repositoryInterface.deleteAllContacts();
                        DECLARATION_DATE = new Date();
                        declarePositiveInterface.notifyResponse(message);
                    }

                    @Override
                    public void onFailure(String error) {
                        declarePositiveInterface.notifyResponse(error);
                    }
                });
            }
            else{
                declarePositiveInterface.notifyResponse("Non sono stati rilevati contatti negli ultimi 15 giorni");
            }
        }
}

