package com.progetto.covidsafe.services;

import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;

public class ServiceFacade {
    //classe che ci permette di far partire contemporaneamente i service,da un lato disaccoppia l'activity dai service, dall'altro rende più agevole
    //l'utilizzo di quest'ultimi
    private ArrayList<Class> servicesList = new ArrayList<>();
    private Context context ;

    public ServiceFacade(Context context) {
        this.context = context;
        servicesList.add(TransmissionService.class);
        servicesList.add(ScanningService.class);
        servicesList.add(TimerService.class);
    }

    public void start(){
        for(Class service : servicesList){
            startService(context,service);
        }
    }

    public void startService(Context context, Class service) {
        Intent serviceIntent = new Intent(context,service);
        context.startForegroundService(serviceIntent);
    }

    public void stopService(Context context, Class service) {
        context.stopService(new Intent(context, service));
    }

    public void stop(){
        for(Class service : servicesList){
            if(!service.equals(TimerService.class)) {
                stopService(context, service);
            }
        }
    }
}
