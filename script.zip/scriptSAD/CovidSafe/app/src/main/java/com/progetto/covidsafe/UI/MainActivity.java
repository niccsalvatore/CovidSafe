package com.progetto.covidsafe.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import com.progetto.covidsafe.R;
import com.progetto.covidsafe.local.ContactRepository;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.model.UserIdentifier;
import com.progetto.covidsafe.services.ServiceFacade;
import com.progetto.covidsafe.utils.BluetoothReceiver;
import org.altbeacon.beacon.BeaconManager;

import java.util.Date;

import static com.progetto.covidsafe.utils.ConfigurationConstants.PERMISSION_REQUEST_BACKGROUND_LOCATION;
import static com.progetto.covidsafe.utils.ConfigurationConstants.PERMISSION_REQUEST_FINE_LOCATION;


public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1;
    private BluetoothReceiver bluetoothReceiver;
    private ServiceFacade serviceFacade ;
    boolean active = true ;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Contact contact = new Contact(new UserIdentifier(2,3),new Date());
        final ContactRepository contactRepository = ContactRepository.getInstance(getApplication());
        contactRepository.insertContact(contact);
        //Facade utilizzato per gestire semplicemente i servizi,fà partire tutti i servizi attraverso il metodo start
        serviceFacade = new ServiceFacade(this);
        //verifica la disponibilità del bluetooth
        verifyBluetooth();
        /*chiede le autorizzazioni necessarie al funzionamento dell'applicazione e nel caso di esito negativo,avverte l'utente del fatto che l'applicazione potrebbe
        non funzionare  correttamente*/
        checkAuthorization();
        //partono i servizi di scansione e trasmissione,oltre che il servizio giornaliero di controllo contatti obsoleti
        serviceFacade.start();
        //istanziamo un IntentFilter,in altre parole dichiariamo il filtro che utilizzerà il broadcast receiver che,nello specifico,sarà "in ascolto"
        //rispetto ad un eventuale cambiamento dello stato del Bluetooth
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        //creiamo un BluetoothReceiver
        bluetoothReceiver = new BluetoothReceiver();
        //registriamo un bluetoothReceiver
        registerReceiver(bluetoothReceiver, filter);
        //creiamo la gridView e popoliamola opportunamente attraverso un custom Adapter chiamato menuAdapter
        GridView gridView = findViewById(R.id.mainGrid);
        final String [] menuNames = new String[]{"find places","declare positive","start your service","statistics"};
        Resources res = this.getResources();
        final Drawable[] menuImages = new Drawable[]{ ResourcesCompat.getDrawable(res, R.drawable.search, null),ResourcesCompat.getDrawable(res, R.drawable.alert2, null),ResourcesCompat.getDrawable(res, R.drawable.work, null),ResourcesCompat.getDrawable(res, R.drawable.statistics, null),};
        MenuAdapter menuAdapter = new MenuAdapter(this,menuNames,menuImages);
        gridView.setAdapter(menuAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            @Override
                                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                                String item = menuNames[position];
                                                switch (item) {
                                                    case "find places":
                                                        Toast.makeText(MainActivity.this,"TODO.",Toast.LENGTH_SHORT).show();
                                                        break;
                                                    case "declare positive":
                                                        //android utilizza un meccanismo di comunicazione basato sugli intent,dichiariamo quindi un intent
                                                        //opportuno in maniera tale che alla pressione del tasto,saremo in grado di spostarci in un'altra activity
                                                        Intent positivityIntent = new Intent(MainActivity.this, DeclarePositiveActivity.class);
                                                        startActivity(positivityIntent);
                                                        break;
                                                    case "statistics":
                                                        Toast.makeText(MainActivity.this,/*"Statistics,TODO."*/""+contactRepository.syncGetAllContacts().size(),Toast.LENGTH_SHORT).show();
                                                        break;
                                                    case "start your service":

                                                        if(active) {
                                                        serviceFacade.stop();
                                                        Toast.makeText(MainActivity.this,"covidsafe has been interrupted!",Toast.LENGTH_SHORT).show();
                                                            active=false;
                                                        }
                                                        else{
                                                            serviceFacade.start();
                                                            active =true;
                                                            Toast.makeText(MainActivity.this,"covidsafe restarted!",Toast.LENGTH_SHORT).show();
                                                        }
                                                        break;
                                                }
                                            }
                                        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregisterReceiver(bluetoothReceiver);
    }
    @Override
    protected void onPause() {
        super.onPause();
    }
    private void verifyBluetooth() {

        try
        {
            if (!BeaconManager.getInstanceForApplication(this).checkAvailability()) {
                BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                //se il bluetooth è disponibile sul dispositivo,ma è spento,richiediamo di accenderlo
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                }
            }
        }
        catch (RuntimeException e) {
            //se il bluetooth LE non è disponibile,informiamo l'utente
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Bluetooth LE not available");
            builder.setMessage("Sorry, this device does not support Bluetooth LE.The application will shut down.");
            builder.setPositiveButton(android.R.string.ok, null);
            builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    finish();
                    System.exit(0);
                }

            });
            builder.show();

        }

    }
    public void checkAuthorization(){
        if (this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {

                if (this.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    if (!this.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle("This app needs background location access");
                        builder.setMessage("Please grant location access so this app can detect beacons in the background.");
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                            @TargetApi(23)
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                requestPermissions(new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                                        PERMISSION_REQUEST_BACKGROUND_LOCATION);
                            }

                        });
                        builder.show();
                    }
                    else {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle("Functionality limited");
                        builder.setMessage("Since background location access has not been granted, this app will not be able to discover beacons in the background.  Please go to Settings -> Applications -> Permissions and grant background location access to this app.");
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                            @Override
                            public void onDismiss(DialogInterface dialog) {
                            }

                        });
                        builder.show();
                    }

            }
        } else {
            if (!this.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                        PERMISSION_REQUEST_FINE_LOCATION);
            }
            else {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Functionality limited");
                builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons.  Please go to Settings -> Applications -> Permissions and grant location access to this app.");
                builder.setPositiveButton(android.R.string.ok, null);
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                    @Override
                    public void onDismiss(DialogInterface dialog) {
                    }

                });
                builder.show();
            }

        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,  String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_FINE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("permission", "fine location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }

                    });
                    builder.show();
                }
                return;
            }
            case PERMISSION_REQUEST_BACKGROUND_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("permission : ", "background location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since background location access has not been granted, this app will not be able to discover beacons when in the background.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }

                    });
                    builder.show();
                }

            }
        }
    }
}








