package com.progetto.covidsafe.services;

import android.app.Notification;
import android.app.Service;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseSettings;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.progetto.covidsafe.utils.NotificationCreator;
import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.BeaconTransmitter;
import java.util.Collections;
import static com.progetto.covidsafe.utils.ConfigurationConstants.APPLICATION_UUID;
import static com.progetto.covidsafe.utils.ConfigurationConstants.TRANSMITTER_MAJOR;
import static com.progetto.covidsafe.utils.ConfigurationConstants.TRANSMITTER_MINOR;


public class TransmissionService extends Service {
        private BeaconParser beaconParser;
        private BeaconTransmitter beaconTransmitter;

        @Override
        public void onCreate() {
           /*Creiamo la notifica necessaria ad un foreground service,ovvero un servizio attivo che mostra costantemente una notifica all'utente.
            questo tipo di servizio è necessario poichè android pone restrizioni di rilievo sull'utilizzo di servizi in background (senza notifica)
            limitandone la durata a quella dello stesso ciclo di vita dell'app.Dal momento che invece la trasmissione doveva avvenire continuativamente,
            si è optato per un ForegroundService*/
            Notification notification = NotificationCreator.getNotification(this); // usiamo un singleton per associare a tutti i servizi la stessa notifica a video
            //quando il servizio viene creato per la prima volta,viene fatto partire.
            startForeground(1, notification);
            //la classe Beacon modella un oggetto hardware : il beacon appunto, ovvero un dispositivo attivo,dotato di antenna.
            final Beacon beacon = new Beacon.Builder()
                    .setId1(APPLICATION_UUID)   //ID dell'applicazione,ci permette di annunciare il nostro disposivo come registrato all'applicazione
                    .setId2(TRANSMITTER_MINOR)  //minor e major sono due interi che fungono da identificativo univoco (fase di registrazione non implementata perchè esulante dal nostro caso d'uso)
                    .setId3(TRANSMITTER_MAJOR)
                    .setManufacturer(0x0118)
                    .setTxPower(-59)
                    .setDataFields(Collections.singletonList(0L))
                    .build();
            //ciascuna casa produttrice  possiede il proprio layout proprietario(Apple = Ibeacon,Google = eddystone).
            // Si è scelto di utilizzare AltBeacon poichè è una libreria altamente flessibile ed openSource
            beaconParser = new BeaconParser().setBeaconLayout(BeaconParser.ALTBEACON_LAYOUT);
            beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
            beaconTransmitter.startAdvertising(beacon, new AdvertiseCallback() {
                @Override
                public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                    super.onStartSuccess(settingsInEffect);

                }

                @Override
                public void onStartFailure(int errorCode) {
                    super.onStartFailure(errorCode);
                }
            });
            super.onCreate();
        }


        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            //Metodo richiamato subito dopo "startForeground": la costante "START_NOT_STICKY" indica il fatto che il servizio
            //se interrotto in fase di esecuzione,non deve essere richiamato fino ad una nuova esplicita chiamata di start
            return START_NOT_STICKY;
        }

        @Override
        public void onDestroy() {
            beaconTransmitter.stopAdvertising();
            super.onDestroy();
        }

        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

}
