package com.progetto.covidsafe.services;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.progetto.covidsafe.local.RepositoryInterface;
import com.progetto.covidsafe.utils.TimerReceiver;
import com.progetto.covidsafe.utils.NotificationCreator;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.local.ContactRepository;
import java.util.List;

public class TimerService extends Service {
    private TimerReceiver timerReceiver;
    private RepositoryInterface repositoryInterface ;


    public void onCreate() {
        super.onCreate();
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        timerReceiver = TimerReceiver.getInstance(this);
        repositoryInterface = ContactRepository.getInstance(getApplication());
        Notification notification = NotificationCreator.getNotification(this);
        List<Contact> contactList = repositoryInterface.syncGetAllContacts();
        if(contactList!=null) {
            for (Contact contact : contactList) {
                //se il contatto è obsoleto,ovvero è più vecchio di quindici giorni,eliminare il contatto
                if (System.currentTimeMillis() - contact.getContactDate().getTime() >= 1000 * 60 * 60 * 24 * 15) {
                    repositoryInterface.deleteContact(contact);
                }
            }
        }
        //il servizio controlla i contatti (startForeground -> onStartCommand)
        startForeground(1,notification);
        //il servizio setta di nuovo l'alarm
        timerReceiver.setAlarm(this);
        //il servizio si distrugge
        stopForeground(true);
        stopSelf();
        //nel caso in cui il processo venisse killato ( ad esempio poichè il sistema non più memoria sufficiente) il servizio viene ricreato e rilanciato
        //questa scelta è stata presa poichè il servizio è di vitale importanza affinchè l'applicazione funzioni correttamente
        return START_STICKY;

    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}