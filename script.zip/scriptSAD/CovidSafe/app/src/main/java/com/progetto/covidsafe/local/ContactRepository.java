package com.progetto.covidsafe.local;

import android.app.Application;
import android.os.AsyncTask;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import com.progetto.covidsafe.controller.ContactControllerInterface;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.model.UserIdentifier;
import java.util.List;

public class ContactRepository implements RepositoryInterface{

    private ContactDAO contactDAO;
    private static ContactRepository contactRepository;
    private List<UserIdentifier> allUserIdentifiers;
    private List<Contact> allContacts;
    public static synchronized ContactRepository getInstance(Application application) {
        if (contactRepository == null) {
            contactRepository = new ContactRepository(application);
        }
        return contactRepository;
    }

    private ContactRepository(Application application) {
        LocalDatabase localDatabase = LocalDatabase.getInstance(application);
        contactDAO = localDatabase.contactDAO();
        getAllUserIdentifiers().observeForever(new Observer<List<UserIdentifier>>() {
            @Override
            public void onChanged(List<UserIdentifier> userIdentifiers) {
                allUserIdentifiers=userIdentifiers;
            }
        });

        getAllContacts().observeForever(new Observer<List<Contact>>() {
            @Override
            public void onChanged(List<Contact> contacts) {
                allContacts=contacts;
            }
        });
    }
    @Override
    public void insertContact(Contact  contact) {
        new InsertContactAsyncTask(contactDAO).execute(contact);
    }
    @Override
    public void deleteContact(Contact contact) {
        new deleteContactAsyncTask(contactDAO).execute(contact);
    }
    @Override
    public void deleteAllContacts() {
        new deleteAllContactsAsyncTask(contactDAO).execute();
    }

    public LiveData<List<Contact>> getAllContacts(){
         return contactDAO.getAllContacts();
    }
    @Override
    public void syncGetAllUserIdentifiers(ContactControllerInterface contactControllerInterface){
        contactControllerInterface.returnIdentifiers(allUserIdentifiers);
    }
    @Override
    public List<Contact> syncGetAllContacts(){
        return allContacts;
    }

    public LiveData<List<UserIdentifier>> getAllUserIdentifiers(){
        return contactDAO.syncGetAllUserIdentifiers();
    }


    private static class InsertContactAsyncTask extends AsyncTask<Contact, Void, Void> {

        private ContactDAO contactDAO;

        private InsertContactAsyncTask(ContactDAO contactDAO) {
            this.contactDAO = contactDAO;
        }

        @Override
        protected Void doInBackground(Contact ... contacts) {
            contactDAO.insertContacts(contacts);
            return null;
        }
    }


    private static class deleteContactAsyncTask extends AsyncTask<Contact, Void, Void> {

        private ContactDAO contactDAO;

        private deleteContactAsyncTask(ContactDAO contactDAO) {
            this.contactDAO = contactDAO;
        }

        @Override
        protected Void doInBackground(Contact ... contacts) {
            contactDAO.deleteContact(contacts);
            return null;
        }
    }


    private static class deleteAllContactsAsyncTask extends AsyncTask<Void, Void, Void> {

        private ContactDAO contactDAO;

        private deleteAllContactsAsyncTask(ContactDAO contactDAO) {
            this.contactDAO = contactDAO;
        }

        @Override
        protected Void doInBackground(Void... Voids) {
            contactDAO.deleteAllContacts();
            return null;
        }
    }



}
