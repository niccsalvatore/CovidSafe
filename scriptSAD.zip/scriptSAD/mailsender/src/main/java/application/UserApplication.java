package application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import application.repositories.UserRepository;

@SpringBootApplication
@EnableAsync
public class UserApplication implements CommandLineRunner {

   
    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }

    @Autowired
    private UserRepository userRepository;
    
	public void run(String... args) throws Exception {
				
	  		

			}
		
	}
	

