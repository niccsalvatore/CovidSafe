package com.progetto.covidsafe.UI;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.progetto.covidsafe.controller.ContactController;
import com.progetto.covidsafe.R;
import com.progetto.covidsafe.controller.ContactControllerInterface;

public class DeclarePositiveActivity extends AppCompatActivity implements DeclarePositiveInterface {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        final ContactControllerInterface contactControllerInterface = ContactController.getInstance(getApplication(),this);
        setContentView(R.layout.activity_declare_positive);
        final CheckBox check = findViewById(R.id.positiveCheckBox);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //la view delega al session controller la business logic
              contactControllerInterface.notifyPositivity();
            }
        });
    }
    //la view ha la sola responsabilità di mostrare dati a video.In questo caso,tramite il metodo "notifyResponse" viene semplicemente
    //mostrato all'utente il messaggio di avvenuta notifica o,eventualmente di errore.
    @Override
    public void notifyResponse(String string) {
        Toast.makeText(this,string,Toast.LENGTH_SHORT).show();
    }
}
