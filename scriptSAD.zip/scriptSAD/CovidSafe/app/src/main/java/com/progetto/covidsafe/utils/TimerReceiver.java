package com.progetto.covidsafe.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.progetto.covidsafe.UI.MainActivity;
import com.progetto.covidsafe.services.TimerService;

public class TimerReceiver extends BroadcastReceiver
{
    private static TimerReceiver timerReceiver;

    public TimerReceiver() {

    }

    public static TimerReceiver getInstance(Context context){
        //con un singleton evitiamo che ogni qual volta  si apra l'applicazione,venga settato un nuovo alarm
        if(timerReceiver ==null){
            timerReceiver =new TimerReceiver();
            timerReceiver.setAlarm(context);
        }
        return timerReceiver;
    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
           Intent intent1 = new Intent(context, MainActivity.class);
            context.startActivity(intent);
        }
    }


    public void setAlarm(Context context)
    {
        AlarmManager alarmManager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, TimerService.class);
        PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, 0);
        //settiamo un alarm che sia preciso (Android verrà forzato a schedularlo all'ora stabilita) e che sopravviva alla Doze Mode
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC, System.currentTimeMillis()+1000*60*60*24, pendingIntent);
    }

    public void CancelAlarm(Context context)
    {
        Intent intent = new Intent(context, TimerService.class);
        PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, 0);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }

}
