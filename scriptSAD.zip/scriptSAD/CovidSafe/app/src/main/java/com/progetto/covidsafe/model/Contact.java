package com.progetto.covidsafe.model;

import androidx.annotation.NonNull;
import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.progetto.covidsafe.utils.DateConverter;

import org.jetbrains.annotations.NotNull;

import java.util.Date;
//Classe che modella un contatto,tali contatti verranno salvati sul database
@Entity(tableName = "contacts")
public class Contact {
    @PrimaryKey
    @Embedded
    @NonNull
    private UserIdentifier userIdentifier;
    @TypeConverters({DateConverter.class})
    private Date contactDate;

    public Contact(@NotNull UserIdentifier userIdentifier, Date contactDate) {
        this.userIdentifier = userIdentifier;
        this.contactDate = contactDate;
    }

    @NotNull
    public UserIdentifier getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(@NotNull UserIdentifier userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public Date getContactDate() {
        return contactDate;
    }

    public void setContactDate(Date contactDate) {
        this.contactDate = contactDate;
    }

    @Override
    public boolean equals(Object o) {
        Contact contact = (Contact) o;
        return this.getUserIdentifier().equals(contact.getUserIdentifier());
    }
}
 