package com.progetto.covidsafe.services;

import com.progetto.covidsafe.utils.NotificationCreator;
import com.progetto.covidsafe.controller.ContactController;
import com.progetto.covidsafe.controller.ContactControllerInterface;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import androidx.annotation.Nullable;
import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
import java.util.Collection;
import static com.progetto.covidsafe.utils.ConfigurationConstants.APPLICATION_UUID;

public class ScanningService extends Service implements BeaconConsumer {
    protected static final String TAG = "RangingActivity";
    private BeaconManager beaconManager;
    private ContactControllerInterface contactControllerInterface;



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        beaconManager = BeaconManager.getInstanceForApplication(this);
        beaconManager.getBeaconParsers().clear();
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.ALTBEACON_LAYOUT));
        beaconManager.bind(this);
        beaconManager.setForegroundBetweenScanPeriod(1000*60*5);
        beaconManager.setForegroundScanPeriod(1000*2);
        onBeaconServiceConnect();
        Notification notification = NotificationCreator.getNotification(this);
        startForeground(1, notification);
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            beaconManager.stopRangingBeaconsInRegion(new Region("test", Identifier.parse(APPLICATION_UUID), null, null));
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        beaconManager.unbind(this);
        super.onDestroy();
    }

    @Override
        public void onBeaconServiceConnect () {
        contactControllerInterface =  ContactController.getInstance(getApplication(),null);
            try {
                //inizia la scansione con il metodo startRangingBeaconsInRegion : uniqueID : id di riferimento della regione,
                // Identifier.parse : id dell'applicazione,permette di filtrare i beacon scannerizzati,accettando solo quelli appartenenti all'applicazione,
               // id2 e id3 : dal momento che lo ScanningService non cerca un beacon specifico,questi due campi sono stati settati a null
                beaconManager.startRangingBeaconsInRegion(new Region("test", Identifier.parse(APPLICATION_UUID), null, null));
                beaconManager.addRangeNotifier(new RangeNotifier() {
                    @Override
                    public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
                        if (beacons.size() >0) {
                            //dal momento che la classe ScanningService si occupa esclusivamente dello scanning,si demanda l'elaborazione al controller
                            contactControllerInterface.checkContacts(beacons);
                        }
                    }
                });
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
}



