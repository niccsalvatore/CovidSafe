package com.progetto.covidsafe.remote;

import com.progetto.covidsafe.model.UserIdentifier;
import java.util.List;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import static com.progetto.covidsafe.utils.ConfigurationConstants.POST_REQUEST_RELATIVE_URL;


public interface MailServiceApi {
    @POST(POST_REQUEST_RELATIVE_URL)
    Call<ResponseBody> sendIdentifiers(
            @Body List<UserIdentifier> userIdentifiers
    ) ;
}