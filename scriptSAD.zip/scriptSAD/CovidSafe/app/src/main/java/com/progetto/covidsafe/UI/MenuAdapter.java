package com.progetto.covidsafe.UI;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.progetto.covidsafe.R;

public class MenuAdapter extends BaseAdapter {

    private final Context context;
    private final String[] fieldNames;
    private final Drawable[] images;

    //all'adapter passeremo il context, i nomi dei campi di ogni cella della griglia e le immagini da inserire in ogni cella
    public MenuAdapter(Context context, String[] fieldNames, Drawable [] images ) {
        this.context = context;
        this.fieldNames = fieldNames;
        this.images = images;
    }


    @Override
    public int getCount() {
        return fieldNames.length;
    }


    @Override
    public long getItemId(int position) {
        return 0;
    }


    @Override
    public Object getItem(int position) {
        return null;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final String fieldName = fieldNames[position];
        final Drawable image = images[position];

        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.cell, null);
        }



        final TextView textView =   convertView.findViewById(R.id.textView);
        final ImageView imageView = convertView.findViewById(R.id.imageView);


        textView.setText(fieldName);
        imageView.setImageDrawable(image);

        return convertView;
    }


}
