package com.progetto.covidsafe.remote;

import com.progetto.covidsafe.model.UserIdentifier;
import java.util.List;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Network {
    //la classe network incapsula tutti gli oggetti ed i metodi necessari ad interfacciarsi con l'esterno,sulla rete
    private MailServiceApi mailServiceApi;
    private static Network network;

    private Network() {
        mailServiceApi = RefrofitService.getInstance();
    }
    //Creiamo un unico punto di accesso verso l'esterno
    public static synchronized Network getInstance() {
        if (network == null) {
            network = new Network();
        }
        return network;
    }

    public void sendIdentifiers(List<UserIdentifier> userIdentifiers, final NetworkCallback networkCallback) {
        Call<ResponseBody> call = mailServiceApi.sendIdentifiers(userIdentifiers);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            //l'onResponse denota semplicemente una risposta che può essere positiva (nel nostro caso POST effettuata con successo)
            // o negativa (a titolo di esempio,401 : Unauthorized)
            public void onResponse(Call<ResponseBody> call,Response<ResponseBody> response) {
                if (response.isSuccessful()){
                    //se la risposta è stata effettuata con successo, utilizziamo il metodo dell'interfaccia per demandare al controller la responsabilità di decidere
                    //sul da farsi
                    networkCallback.onSuccess("notifications sent with success!");
                }
                else{
                    //in caso di risposte differenti da quella di successo ( 400 : bad request,401  bad credentials ...) utilizziamo il metodo dell'interfaccia
                    //per demandare al controller la responsabilità di decidere sul da farsi
                    networkCallback.onFailure(response.message());
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                networkCallback.onFailure(t.getMessage());
            }
        });

    }
}


