package com.progetto.covidsafe.remote;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import static com.progetto.covidsafe.utils.ConfigurationConstants.BASE_MAIL_URL;
import static com.progetto.covidsafe.utils.ConfigurationConstants.WEB_SERVICE_AUTH_PASSWORD;
import static com.progetto.covidsafe.utils.ConfigurationConstants.WEB_SERVICE_AUTH_USERNAME;

public class RefrofitService {
    //l'oggetto mailRetrofit è necessario per creare (attraverso il metodo "create") un'istanza dell'interfaccia (nel caso specifico MailServiceApi)
    private static Retrofit mailRetrofit;

    public static MailServiceApi getInstance() {

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new AuthInterceptor(WEB_SERVICE_AUTH_USERNAME, WEB_SERVICE_AUTH_PASSWORD))
                .build();
        if (mailRetrofit == null) {
            mailRetrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(BASE_MAIL_URL).client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return mailRetrofit.create(MailServiceApi.class);
    }
}