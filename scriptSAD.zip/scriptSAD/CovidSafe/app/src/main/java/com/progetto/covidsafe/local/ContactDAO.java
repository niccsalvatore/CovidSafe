package com.progetto.covidsafe.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import com.progetto.covidsafe.model.Contact;
import com.progetto.covidsafe.model.UserIdentifier;
import java.util.List;

@Dao
public interface ContactDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertContacts(Contact...contacts);

    @Delete
    void deleteContact(Contact...contacts);

    @Query("SELECT * FROM contacts ")
    LiveData<List<Contact>> getAllContacts();

    @Query("SELECT minor,major FROM contacts ")
    LiveData<List<UserIdentifier>> syncGetAllUserIdentifiers();

    @Query("DELETE FROM contacts")
    void deleteAllContacts();
}
