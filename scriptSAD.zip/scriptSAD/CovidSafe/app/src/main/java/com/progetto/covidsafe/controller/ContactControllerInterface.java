package com.progetto.covidsafe.controller;

import com.progetto.covidsafe.model.UserIdentifier;

import org.altbeacon.beacon.Beacon;
import java.util.Collection;
import java.util.List;

public interface ContactControllerInterface {
    void checkContacts (Collection<Beacon> beacons);
    void notifyPositivity();
    void returnIdentifiers(List<UserIdentifier> userIdentifiers);
}
