package com.progetto.covidsafe.local;

import com.progetto.covidsafe.controller.ContactControllerInterface;
import com.progetto.covidsafe.model.Contact;

import java.util.List;

public interface RepositoryInterface {
 void insertContact(Contact contact);
 void deleteContact(Contact contact);
 void deleteAllContacts();
 void syncGetAllUserIdentifiers(ContactControllerInterface contactControllerInterface);
 List<Contact> syncGetAllContacts();
}
